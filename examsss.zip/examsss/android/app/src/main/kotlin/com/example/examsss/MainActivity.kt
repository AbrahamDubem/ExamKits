package com.example.examsss

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
